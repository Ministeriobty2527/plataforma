import React from 'react';

const DoePage = () => {
  return (
    <div>
      {/* Banner da página */}
      <div className="bg-accent text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Faça uma Doação</h1>
          <p className="text-xl max-w-3xl mx-auto">
            Sua contribuição é fundamental para mantermos nosso trabalho com crianças e jovens em situação de vulnerabilidade.
          </p>
        </div>
      </div>

      {/* Seção Informações de Doação */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Como Doar</h2>
            <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-lg">
              Existem várias formas de contribuir financeiramente com a Base de Amor e Justiça. Escolha a que for mais conveniente para você.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="bg-light p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold text-primary mb-6">Dados Bancários</h3>
              
              <div className="bg-white p-6 rounded-md mb-6 border-l-4 border-primary">
                <p className="mb-2"><strong>Banco:</strong> 033 - Santander</p>
                <p className="mb-2"><strong>Agência:</strong> 1526</p>
                <p className="mb-2"><strong>Conta:</strong> 13002273-6</p>
                <p className="mb-2"><strong>Tipo:</strong> Conta corrente</p>
                <p className="mb-2"><strong>Nome:</strong> CJMBT YESHUA</p>
              </div>
              
              <h3 className="text-2xl font-bold text-primary mb-6">PIX</h3>
              <div className="bg-white p-6 rounded-md border-l-4 border-primary">
                <p className="mb-2"><strong>Chave PIX (CNPJ):</strong> 04.577.743/0001-80</p>
                <p className="mb-2"><strong>Nome:</strong> CJMBT YESHUA</p>
                
                {/* Placeholder para QR Code PIX */}
                <div className="bg-gray-200 w-48 h-48 mt-4 mx-auto rounded-md flex items-center justify-center">
                  <span className="text-gray-500">QR Code PIX</span>
                </div>
              </div>
            </div>
            
            <div className="bg-light p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold text-primary mb-6">Por que doar?</h3>
              <p className="mb-4">
                Sua doação é essencial para mantermos e expandirmos nossos projetos que impactam diretamente a vida de crianças e jovens em situação de vulnerabilidade nas comunidades do Tuiuti e Mangueira.
              </p>
              <p className="mb-4">
                Com sua contribuição, podemos:
              </p>
              <ul className="list-disc pl-6 mb-6 space-y-2">
                <li>Oferecer atividades esportivas e educacionais de qualidade</li>
                <li>Fornecer material didático e esportivo</li>
                <li>Capacitar nossa equipe de educadores e voluntários</li>
                <li>Manter nossa infraestrutura segura e acolhedora</li>
                <li>Expandir nosso atendimento para mais crianças e jovens</li>
              </ul>
              
              {/* Placeholder para imagem */}
              <div className="bg-gray-200 w-full h-64 rounded-md flex items-center justify-center">
                <span className="text-gray-500">Imagem de crianças beneficiadas</span>
              </div>
              
              <div className="mt-6 text-center">
                <button className="bg-accent text-white font-semibold py-3 px-8 rounded-md hover:bg-accent/90 transition-all text-center">Doar Agora</button>
              </div>
            </div>
          </div>
          
          <div className="bg-primary/5 p-8 rounded-lg shadow-md">
            <h3 className="text-2xl font-bold text-primary mb-6 text-center">Outras formas de contribuir</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-md shadow-sm">
                <h4 className="text-xl font-bold text-primary mb-4">Doação de materiais</h4>
                <p>
                  Você pode doar materiais esportivos, didáticos, equipamentos ou outros itens que possam ser úteis para nossas atividades. Entre em contato para saber nossas necessidades atuais.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-md shadow-sm">
                <h4 className="text-xl font-bold text-primary mb-4">Voluntariado</h4>
                <p>
                  Doe seu tempo e talento! Temos diversas áreas onde você pode contribuir como voluntário, desde atividades diretas com as crianças até apoio administrativo e de comunicação.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-md shadow-sm">
                <h4 className="text-xl font-bold text-primary mb-4">Parcerias</h4>
                <p>
                  Empresas e organizações podem estabelecer parcerias conosco para apoiar projetos específicos ou contribuir regularmente com nossas atividades.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Prestação de Contas */}
      <section className="section bg-light">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Transparência</h2>
            <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-lg">
              Prestamos contas regularmente sobre a utilização dos recursos recebidos, garantindo transparência e responsabilidade.
            </p>
          </div>
          
          <div className="bg-white p-8 rounded-lg shadow-md">
            <p className="mb-6">
              A Base de Amor e Justiça e o Ministério BTY têm compromisso com a transparência na gestão dos recursos recebidos. Periodicamente, divulgamos relatórios de atividades e prestação de contas para nossos doadores e parceiros.
            </p>
            <p className="mb-6">
              Se você deseja receber informações sobre como sua doação está sendo utilizada ou acessar nossos relatórios de prestação de contas, entre em contato conosco pelo e-mail <a href="mailto:contato@ministeriobty.com.br" className="text-primary hover:underline">contato@ministeriobty.com.br</a>.
            </p>
            
            {/* Placeholder para gráfico ou imagem de prestação de contas */}
            <div className="bg-gray-200 w-full h-64 rounded-md flex items-center justify-center">
              <span className="text-gray-500">Gráfico de distribuição de recursos</span>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Depoimentos */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Depoimentos de Doadores</h2>
            <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-lg">
              Conheça a experiência de quem já contribui com nosso trabalho.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-light p-6 rounded-lg shadow-md">
              <p className="italic mb-4">
                "Contribuir mensalmente com a Base de Amor e Justiça me dá a certeza de que estou ajudando a transformar vidas. Os relatórios que recebo mostram o impacto real do trabalho realizado."
              </p>
              <p className="font-semibold text-primary">C.R., doador mensal há 3 anos</p>
            </div>
            
            <div className="bg-light p-6 rounded-lg shadow-md">
              <p className="italic mb-4">
                "Nossa empresa estabeleceu uma parceria com a Base de Amor e Justiça e ficamos impressionados com a seriedade e o compromisso da equipe. O trabalho que realizam é transformador."
              </p>
              <p className="font-semibold text-primary">M.T., empresa parceira</p>
            </div>
            
            <div className="bg-light p-6 rounded-lg shadow-md">
              <p className="italic mb-4">
                "Comecei doando materiais esportivos e hoje contribuo mensalmente. Ver o sorriso das crianças e o desenvolvimento delas é a maior recompensa que poderia ter."
              </p>
              <p className="font-semibold text-primary">A.S., doadora e voluntária</p>
            </div>
          </div>
        </div>
      </section>

      {/* Chamada para Ação */}
      <section className="section bg-primary text-white">
        <div className="container">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Faça parte dessa história</h2>
            <p className="max-w-3xl mx-auto text-lg mb-8">
              Sua contribuição, independentemente do valor, faz diferença na vida de muitas crianças e jovens. Doe hoje e ajude a transformar o futuro.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <button className="bg-white text-accent font-semibold py-2 px-6 rounded-md hover:bg-gray-100 transition-all text-center">Doar Agora</button>
              <a href="/contato" className="bg-transparent border-2 border-white text-white font-semibold py-2 px-6 rounded-md hover:bg-white/10 transition-all text-center">Entre em Contato</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DoePage;
