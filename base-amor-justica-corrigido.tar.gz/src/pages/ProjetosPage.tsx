import React from 'react';

const ProjetosPage = () => {
  return (
    <div>
      {/* Banner da página */}
      <div className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Nossos Projetos</h1>
          <p className="text-xl max-w-3xl mx-auto">
            Conheça as iniciativas que transformam vidas através do esporte, educação e evangelho nas comunidades do Tuiuti e Mangueira.
          </p>
        </div>
      </div>

      {/* Introdução */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Nossos Pilares de Atuação</h2>
            <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-lg">
              Na Base de Amor e Justiça, acreditamos em uma abordagem integrada para transformação social. 
              Nossos projetos se baseiam em três pilares fundamentais: esporte para atrair, educação para capacitar 
              e evangelho para transformar. Juntos, esses pilares formam a base de todas as nossas iniciativas.
            </p>
          </div>
        </div>
      </section>

      {/* Projeto 1: Proteção de Meninas */}
      <section className="section bg-light">
        <div className="container">
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold text-primary mb-4">Proteção de Meninas</h2>
              <div className="w-24 h-1 bg-secondary mb-6"></div>
              <p className="mb-4">
                Nosso projeto de proteção de meninas é uma iniciativa central da Base de Amor e Justiça, focada na prevenção da gravidez precoce e do tráfico sexual nas comunidades do Tuiuti e Mangueira. Reconhecemos que as meninas em situação de vulnerabilidade social estão expostas a riscos específicos que podem comprometer seu desenvolvimento e futuro.
              </p>
              <p className="mb-4">
                Através de encontros semanais, oferecemos um espaço seguro onde as meninas recebem orientação sobre saúde reprodutiva, autoestima, relacionamentos saudáveis e reconhecimento de situações de risco. Contamos com profissionais capacitados que abordam esses temas de forma sensível e adequada à idade das participantes.
              </p>
              <p>
                Além das orientações, realizamos atividades que fortalecem a autoconfiança, o protagonismo e o desenvolvimento de habilidades para a vida. Trabalhamos em parceria com a rede de proteção social para garantir atendimento integral e encaminhamento adequado em casos de violação de direitos.
              </p>
            </div>
            <div className="md:w-1/2 bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold text-primary mb-4">Atividades do Projeto</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Oficinas de Educação Sexual</h4>
                  <p>
                    Realizamos oficinas educativas sobre saúde reprodutiva, prevenção de gravidez e doenças sexualmente transmissíveis, sempre com linguagem adequada e respeitando os valores familiares e cristãos.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Mentoria e Acompanhamento</h4>
                  <p>
                    Cada menina participante recebe acompanhamento personalizado de uma mentora que oferece orientação, apoio emocional e serve como modelo positivo de referência.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Capacitação Profissional</h4>
                  <p>
                    Para adolescentes, oferecemos cursos de capacitação profissional que ampliam as perspectivas de futuro e fortalecem a autonomia financeira, fator importante na prevenção de situações de exploração.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projeto 2: Esporte para Todos */}
      <section className="section bg-white">
        <div className="container">
          <div className="flex flex-col md:flex-row-reverse gap-8 items-center">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold text-primary mb-4">Esporte para Todos</h2>
              <div className="w-24 h-1 bg-secondary mb-6"></div>
              <p className="mb-4">
                O projeto Esporte para Todos utiliza a prática esportiva como ferramenta de atração e desenvolvimento integral de crianças e jovens. Acreditamos que o esporte não é apenas uma atividade física, mas um poderoso meio de ensinar valores como disciplina, trabalho em equipe, respeito e perseverança.
              </p>
              <p className="mb-4">
                Oferecemos atividades esportivas regulares em diversas modalidades, como futebol, vôlei, basquete e outras, adaptadas às diferentes faixas etárias. Todas as atividades são conduzidas por profissionais qualificados que, além de ensinar as técnicas esportivas, transmitem valores e princípios fundamentais para a formação do caráter.
              </p>
              <p>
                O esporte funciona como porta de entrada para outros projetos da Base de Amor e Justiça. Muitas crianças e jovens que iniciam nas atividades esportivas acabam se envolvendo também nos programas educacionais e espirituais, beneficiando-se de uma formação integral.
              </p>
            </div>
            <div className="md:w-1/2 bg-light p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold text-primary mb-4">Modalidades e Benefícios</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Futebol</h4>
                  <p>
                    Nossa modalidade mais popular, com treinos regulares para diferentes faixas etárias. Além das técnicas do esporte, ensinamos trabalho em equipe, respeito às regras e disciplina.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Vôlei e Basquete</h4>
                  <p>
                    Oferecemos estas modalidades como alternativas ao futebol, ampliando as possibilidades de participação e descoberta de talentos em diferentes esportes.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Jogos Cooperativos</h4>
                  <p>
                    Para os mais novos, realizamos jogos e brincadeiras que desenvolvem coordenação motora, socialização e valores como cooperação e respeito ao próximo.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projeto 3: Educação Transformadora */}
      <section className="section bg-light">
        <div className="container">
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold text-primary mb-4">Educação Transformadora</h2>
              <div className="w-24 h-1 bg-secondary mb-6"></div>
              <p className="mb-4">
                O projeto Educação Transformadora visa complementar a educação formal recebida nas escolas, oferecendo atividades educacionais que desenvolvem habilidades cognitivas, socioemocionais e práticas. Acreditamos que a educação é um caminho fundamental para romper ciclos de pobreza e vulnerabilidade social.
              </p>
              <p className="mb-4">
                Oferecemos reforço escolar para crianças com dificuldades de aprendizagem, oficinas de leitura e escrita, aulas de informática básica e avançada, e cursos profissionalizantes para adolescentes. Todas as atividades são planejadas considerando as necessidades específicas de cada faixa etária e as demandas do mercado de trabalho local.
              </p>
              <p>
                Além do conteúdo técnico, trabalhamos valores como responsabilidade, ética, criatividade e pensamento crítico. Nosso objetivo é formar não apenas bons estudantes ou profissionais, mas cidadãos conscientes e comprometidos com a transformação de suas realidades.
              </p>
            </div>
            <div className="md:w-1/2 bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold text-primary mb-4">Programas Educacionais</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Reforço Escolar</h4>
                  <p>
                    Apoio pedagógico para crianças e adolescentes com dificuldades de aprendizagem, com foco em português e matemática, disciplinas fundamentais para o desenvolvimento acadêmico.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Inclusão Digital</h4>
                  <p>
                    Aulas de informática básica e avançada, preparando crianças e jovens para os desafios do mundo digital e ampliando suas oportunidades de estudo e trabalho.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Preparação Profissional</h4>
                  <p>
                    Para adolescentes e jovens, oferecemos cursos profissionalizantes em áreas como administração, empreendedorismo, design gráfico e programação, além de orientação vocacional.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projeto 4: Evangelho Transformador */}
      <section className="section bg-white">
        <div className="container">
          <div className="flex flex-col md:flex-row-reverse gap-8 items-center">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold text-primary mb-4">Evangelho Transformador</h2>
              <div className="w-24 h-1 bg-secondary mb-6"></div>
              <p className="mb-4">
                O projeto Evangelho Transformador é o coração espiritual da Base de Amor e Justiça. Acreditamos que a verdadeira transformação acontece de dentro para fora, e que os valores cristãos são fundamentais para a formação de caráter e para uma vida plena e significativa.
              </p>
              <p className="mb-4">
                Através de encontros semanais, estudos bíblicos adaptados para diferentes faixas etárias, momentos de louvor e oração, compartilhamos o amor de Deus e os ensinamentos de Yeshua (Jesus) de forma contextualizada e relevante para a realidade das crianças e jovens que atendemos.
              </p>
              <p>
                Respeitamos a diversidade religiosa das famílias e nunca impomos nossas crenças. Nossa abordagem é baseada no amor, no respeito e no exemplo, acreditando que os valores cristãos como amor ao próximo, perdão, honestidade e compaixão são universais e benéficos para todos, independentemente de sua fé pessoal.
              </p>
            </div>
            <div className="md:w-1/2 bg-light p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold text-primary mb-4">Atividades Espirituais</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Encontros Semanais</h4>
                  <p>
                    Realizamos encontros adaptados para diferentes faixas etárias, com momentos de louvor, ensino bíblico, dinâmicas e atividades que tornam o aprendizado espiritual acessível e relevante.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Aconselhamento</h4>
                  <p>
                    Oferecemos aconselhamento espiritual para crianças, jovens e famílias que enfrentam desafios e buscam orientação baseada em princípios bíblicos.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-secondary mb-2">Formação de Líderes</h4>
                  <p>
                    Investimos na formação de jovens líderes que possam multiplicar os valores e princípios aprendidos, tornando-se agentes de transformação em suas próprias comunidades.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Chamada para Ação */}
      <section className="section bg-secondary text-white">
        <div className="container">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Participe dos nossos projetos</h2>
            <p className="max-w-3xl mx-auto text-lg mb-8">
              Você pode contribuir para o sucesso dos nossos projetos de diversas formas: como voluntário, doador ou parceiro institucional. Cada contribuição, por menor que pareça, faz diferença na vida das crianças e jovens que atendemos.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a href="/contato" className="bg-white text-secondary font-semibold py-2 px-6 rounded-md hover:bg-gray-100 transition-all text-center">Seja voluntário</a>
              <a href="/doe" className="btn-accent text-center">Faça uma doação</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProjetosPage;
