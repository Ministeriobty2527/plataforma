import React from 'react';
import Parcerias from '../components/Parcerias';

const QuemSomosPage = () => {
  return (
    <div>
      {/* Banner da página */}
      <div className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Quem Somos</h1>
          <p className="text-xl max-w-3xl mx-auto">
            Conheça a história, missão e valores da Base de Amor e Justiça e nossa conexão com o Ministério BTY.
          </p>
        </div>
      </div>

      {/* Seção História */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-primary mb-4">Nossa História</h2>
            <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
          </div>
          
          <div className="bg-light p-8 rounded-lg shadow-md mb-8 prose max-w-none">
            <p className="mb-4">
              A Base de Amor e Justiça nasceu em 2012 como uma extensão viva e pulsante do trabalho do Ministério BTY (Beit Tefilat Yeshua – Casa de Oração Yeshua), fundado há 25 anos por judeus e árabes crentes em Yeshua (Jesus). Desde o início, nossa identidade foi moldada pelo encontro improvável de povos, unidos não pela tradição dos homens, mas pela verdade da Palavra viva.
            </p>
            <p className="mb-4">
              A visão que acendeu essa chama veio ao coração de Ludwig Goulart, também conhecido como Pastor Papo Reto, que atendeu ao chamado divino para atuar nas comunidades do Tuiuti e da Mangueira, no Rio de Janeiro. Ao lado de Eduardo Stein, fundador do Ministério BTY, Ludwig abriu mão de uma promissora carreira no mundo corporativo — com formação em Business e Planejamento Estratégico por Los Angeles — para investir sua vida no que tem valor eterno: gente.
            </p>
            <p className="mb-4">
              Casado há 23 anos com Patrícia Goulart, Ludwig lançou os alicerces da Base com um propósito claro: levar transformação real através do esporte, da educação e do evangelho. Não oferecemos apenas projetos — oferecemos esperança. Acreditamos que o amor e a justiça são forças ativas que curam, libertam e redirecionam destinos.
            </p>
            <p className="mb-4">
              Ao longo dessa jornada, nossos esforços se concentraram especialmente na proteção e no desenvolvimento integral de crianças e adolescentes, com atenção especial às meninas em situações de risco. Porque para nós, cada vida importa — e cada coração vulnerável é um território sagrado que merece cuidado.
            </p>
            <p className="mb-4">
              Nos últimos anos, o casal Pr. Marcos Vinicius e Adriana Primo tem sido um reforço essencial nessa caminhada. Ele, pastor, educador e vice-presidente do BTY, ela, especialista em psicopedagogia e coordenadora da área de educação. Juntos, têm avançado com coragem e fé no resgate de vidas, facilitando o acesso à transformação para aqueles que a sociedade esqueceu. Onde muitos veem impossibilidade, eles veem sementes. E onde o mundo impõe limites, eles abrem trilhas com graça.
            </p>
            <p className="mb-4">
              Como diz o provérbio: "Defenda os direitos dos pobres e dos necessitados." (Provérbios 31:9)
            </p>
            <p className="mb-4">
              Essa é a nossa missão. Se você quiser saber mais, venha conhecer a Base de Amor e Justiça. Ou adquira o livro "Um Órfão Vive em Família", escrito por Pr. Marcos Vinicius — um convite sincero a enxergar a restauração como realidade possível.
            </p>
            <p className="mb-4">
              Seguimos firmes, porque a justiça sem amor é fria, e o amor sem justiça é cego. Mas quando andam juntos… milagres acontecem.
            </p>
            <p className="text-right font-semibold italic">
              Ludwig Goulart
            </p>
          </div>
          
          <div className="bg-light p-8 rounded-lg shadow-md">
            <h3 className="text-2xl font-bold text-primary mb-4">Ministério BTY</h3>
            <p className="mb-4">
              O Ministério BTY (Beit Tefilat Yeshua - Casa de Oração Yeshua) é uma organização sem fins lucrativos que tem a missão de propagar a restauração social da igreja de Atos e a unidade profética entre Israel e a Igreja. Fundado há 25 anos por judeus e árabes crentes em Yeshua, o ministério atua em diversas frentes sociais e evangelísticas.
            </p>
            <p className="mb-4">
              Como parte do Ministério BTY, a Base de Amor e Justiça compartilha dos mesmos valores e visão, atuando especificamente nas comunidades do Tuiuti e Mangueira com foco na proteção e desenvolvimento de crianças e jovens em situação de vulnerabilidade.
            </p>
            <p>
              A conexão com o Ministério BTY nos proporciona uma base teológica sólida e uma visão ampla de transformação social, permitindo que nosso trabalho seja realizado com excelência e propósito claro. O Ministério BTY é responsável pela manutenção da vida do projeto, garantindo sua sustentabilidade e continuidade.
            </p>
            <div className="mt-6">
              <a href="https://www.ministeriobty.com.br" target="_blank" rel="noopener noreferrer" className="text-primary font-semibold hover:underline">
                Visite o site do Ministério BTY →
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Missão, Visão e Valores */}
      <section className="section bg-light">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Missão, Visão e Valores</h2>
            <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-md mb-8">
            <h3 className="text-2xl font-bold text-primary mb-4">Nossa Missão</h3>
            <p>
              Transformar vidas através do esporte, educação e evangelho, com foco especial na proteção de meninas contra a gravidez precoce e o tráfico sexual nas comunidades do Tuiuti e Mangueira. Buscamos criar oportunidades para que crianças e jovens em situação de vulnerabilidade possam desenvolver seu potencial e construir um futuro digno, rompendo ciclos de pobreza e violência.
            </p>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-md mb-8">
            <h3 className="text-2xl font-bold text-primary mb-4">Nossa Visão</h3>
            <p>
              Ser uma referência em transformação social nas comunidades onde atuamos, formando uma nova geração de líderes comprometidos com valores cristãos e capazes de multiplicar o impacto positivo em suas famílias e comunidades. Visualizamos comunidades onde crianças e jovens estejam protegidos, educados e preparados para um futuro de oportunidades e esperança.
            </p>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-md">
            <h3 className="text-2xl font-bold text-primary mb-4">Nossos Valores</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xl font-bold text-secondary mb-2">Amor</h4>
                <p className="mb-4">
                  Acreditamos que o amor é a força mais poderosa para transformação. Todas as nossas ações são motivadas pelo amor genuíno às pessoas, especialmente às mais vulneráveis.
                </p>
                
                <h4 className="text-xl font-bold text-secondary mb-2">Justiça</h4>
                <p className="mb-4">
                  Buscamos promover justiça social, defendendo os direitos das crianças e jovens e trabalhando para reduzir desigualdades e criar oportunidades equitativas.
                </p>
                
                <h4 className="text-xl font-bold text-secondary mb-2">Integridade</h4>
                <p>
                  Atuamos com transparência, honestidade e coerência em todas as nossas ações, mantendo altos padrões éticos em nosso trabalho.
                </p>
              </div>
              
              <div>
                <h4 className="text-xl font-bold text-secondary mb-2">Excelência</h4>
                <p className="mb-4">
                  Buscamos a excelência em tudo o que fazemos, oferecendo o melhor para as crianças e jovens que atendemos e constantemente aprimorando nossos métodos e práticas.
                </p>
                
                <h4 className="text-xl font-bold text-secondary mb-2">Fé</h4>
                <p className="mb-4">
                  Nossa fé em Yeshua (Jesus) é o fundamento de todo o nosso trabalho, inspirando-nos a servir com amor e dedicação.
                </p>
                
                <h4 className="text-xl font-bold text-secondary mb-2">Transformação</h4>
                <p>
                  Acreditamos no poder da transformação integral - espiritual, emocional, intelectual e social - para mudar não apenas indivíduos, mas famílias e comunidades inteiras.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Plataforma Resgate - Jiu-Jitsu - DESTACADA */}
      <section className="section bg-secondary/10">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-primary mb-4">Plataforma Resgate - Jiu-Jitsu</h2>
            <div className="w-24 h-1 bg-accent mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-lg">
              Transformando vidas através da disciplina e valores das artes marciais.
            </p>
          </div>

          <div className="flex flex-col md:flex-row gap-8 mb-8">
            <div className="md:w-1/2">
              {/* Placeholder para imagem */}
              <div className="bg-gray-200 w-full h-96 mb-4 rounded-md flex items-center justify-center">
                <span className="text-gray-500 text-xl">Imagem da Plataforma Resgate - Jiu-Jitsu</span>
              </div>
            </div>
            <div className="md:w-1/2">
              <h3 className="text-2xl font-bold text-primary mb-4">Projeto de Excelência</h3>
              <p className="mb-4 text-lg">
                <strong>A Plataforma Resgate - Jiu-Jitsu</strong> é um projeto de destaque da Base de Amor e Justiça, parte da Confederação Brasileira de Jiu-Jitsu, que utiliza as artes marciais como ferramenta de transformação na vida de crianças e adolescentes em situação de vulnerabilidade.
              </p>
              <p className="mb-4">
                Coordenado pelo Pr. Marcos Vinícius e Adriana Primo, o projeto une esporte, fé e educação como ferramentas de impacto real, oferecendo suporte, acolhimento e discipulado para ajudar os participantes a reencontrarem propósito e identidade.
              </p>
              <p className="mb-4">
                Através do Jiu-Jitsu, ensinamos valores como disciplina, respeito, perseverança e superação, desenvolvendo não apenas habilidades físicas, mas também formando o caráter e preparando os jovens para enfrentar os desafios da vida.
              </p>
              <p>
                O projeto é reconhecido pela Confederação Brasileira de Jiu-Jitsu e tem trazido resultados significativos na vida dos participantes, promovendo disciplina, autoconfiança e desenvolvimento pessoal através deste esporte individual.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Equipe */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Nossa Equipe</h2>
            <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
            <p className="max-w-3xl mx-auto text-lg">
              Conheça as pessoas dedicadas que fazem a Base de Amor e Justiça acontecer todos os dias.
            </p>
          </div>

          <div className="bg-light p-8 rounded-lg shadow-md mb-8">
            <p className="mb-4">
              Nossa equipe é formada por profissionais e voluntários comprometidos com a transformação social. Contamos com educadores, assistentes sociais, psicólogos, profissionais de educação física e muitos outros que dedicam seu tempo e talento para fazer a diferença na vida das crianças e jovens que atendemos.
            </p>
            <p className="mb-4">
              Sob a liderança de Ludwig Goulart, escritor e fundador, trabalhamos de forma integrada para oferecer o melhor atendimento possível, sempre com foco no desenvolvimento integral e na proteção dos mais vulneráveis. Nossa equipe recebe treinamento constante e atua com base em metodologias comprovadas de intervenção social.
            </p>
            <p>
              Além dos profissionais contratados, contamos com uma rede de voluntários que contribuem em diversas áreas, desde o apoio nas atividades esportivas até o reforço escolar e oficinas especializadas. Se você deseja fazer parte dessa equipe como voluntário, entre em contato conosco!
            </p>
          </div>

          <div className="mb-12">
            <h3 className="text-3xl font-bold text-primary mb-6 text-center">Liderança da Base de Amor e Justiça</h3>
            
            <div className="flex flex-col md:flex-row gap-8 mb-12">
              <div className="md:w-1/2 bg-primary/10 p-6 rounded-lg shadow-md">
                {/* Placeholder para imagem */}
                <div className="bg-gray-200 w-full h-64 mb-4 rounded-md flex items-center justify-center">
                  <span className="text-gray-500">Imagem do Pr. Marcos Vinícius</span>
                </div>
                <h4 className="text-2xl font-bold text-primary mb-2">Pr. Marcos Vinícius</h4>
                <p className="text-gray-600 mb-4 font-semibold">Vice-presidente do Ministério BTY e Responsável pela Base de Amor e Justiça</p>
                <p className="mb-4">
                  Formado em História, Relações Internacionais, Teologia e atualmente cursando Educação Física, o Pr. Marcos Vinícius une conhecimento, prática e sensibilidade pastoral na formação de jovens. Com mais de cinco anos de atuação direta no Ministério BTY, ele exerce a função de vice-presidente da instituição.
                </p>
                <p className="mb-4">
                  Lidera com firmeza e compaixão o desenvolvimento espiritual, emocional e físico de adolescentes e jovens em situação de vulnerabilidade. É também autor do livro "Um órfão vive em família", uma obra que expressa a missão de restaurar o sentido de pertencimento e reconectar corações ao propósito eterno.
                </p>
                <p>
                  Como coordenador da Plataforma Resgate - Jiu-Jitsu, utiliza o esporte como ferramenta de transformação, combinando sua formação multidisciplinar com uma visão integral do desenvolvimento humano.
                </p>
              </div>
              
              <div className="md:w-1/2 bg-primary/10 p-6 rounded-lg shadow-md">
                {/* Placeholder para imagem */}
                <div className="bg-gray-200 w-full h-64 mb-4 rounded-md flex items-center justify-center">
                  <span className="text-gray-500">Imagem da Adriana Primo</span>
                </div>
                <h4 className="text-2xl font-bold text-primary mb-2">Adriana Primo</h4>
                <p className="text-gray-600 mb-4 font-semibold">Educadora e Responsável pelo Desenvolvimento Psicopedagógico</p>
                <p className="mb-4">
                  Adriana Primo lidera a área de educação e psicopedagogia da Base de Amor e Justiça, desenvolvendo metodologias de ensino e cuidado que respeitam a individualidade de cada aluno e promovem verdadeira transformação de vida.
                </p>
                <p className="mb-4">
                  Seu trabalho é focado no desenvolvimento psicopedagógico das crianças e jovens, além de coordenar os programas de alfabetização. Junto com seu esposo, Pr. Marcos Vinícius, forma uma dupla dedicada à transformação integral das vidas atendidas pelo projeto.
                </p>
                <p>
                  Na Plataforma Resgate - Jiu-Jitsu, Adriana contribui com sua expertise educacional, garantindo que o esporte seja uma ferramenta não apenas de disciplina física, mas também de desenvolvimento cognitivo e emocional.
                </p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <h4 className="text-xl font-bold text-primary mb-4">Sobre o Casal</h4>
              <p className="mb-4">
                O pastor Marcos Vinícius e sua esposa, a educadora Adriana Primo, são os líderes responsáveis pela condução da Base de Amor e Justiça do Ministério BTY — um espaço de discipulado, transformação e restauração integral. Juntos, eles coordenam as ações diárias da Plataforma Resgate – Jiu-Jitsu, onde o esporte se une à fé e à educação como ferramentas de impacto real.
              </p>
              <p>
                O casal trabalha em sinergia, combinando a formação multidisciplinar de Marcos com a expertise educacional de Adriana para criar um ambiente de desenvolvimento integral para crianças e jovens. Sua liderança é marcada pelo compromisso com a excelência e pelo profundo amor às pessoas atendidas pela Base de Amor e Justiça.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Parcerias */}
      <Parcerias />

      {/* Chamada para Ação */}
      <section className="section bg-primary text-white">
        <div className="container">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Junte-se a nós nessa missão</h2>
            <p className="max-w-3xl mx-auto text-lg mb-8">
              Você pode fazer parte dessa história de transformação. Seja como voluntário, doador ou parceiro, sua contribuição é fundamental para continuarmos impactando vidas nas comunidades do Tuiuti e Mangueira.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a href="/contato" className="bg-white text-primary font-semibold py-2 px-6 rounded-md hover:bg-gray-100 transition-all text-center">Entre em Contato</a>
              <a href="/doe" className="bg-transparent border-2 border-white text-white font-semibold py-2 px-6 rounded-md hover:bg-white/10 transition-all text-center">Faça uma Doação</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default QuemSomosPage;
