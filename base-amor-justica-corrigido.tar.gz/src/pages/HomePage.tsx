import React from 'react';
import { useTranslation } from 'react-i18next';
import Hero from '../components/Hero';

const AboutSection = () => {
  const { t } = useTranslation();
  
  return (
    <section className="py-16 bg-light">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">{t('about.title')}</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            {t('about.description')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-bold mb-4">{t('about.mission.title')}</h3>
            <p className="mb-4">
              {t('about.mission.text1')}
            </p>
            <p className="mb-4">
              {t('about.mission.text2')}
            </p>
            <div className="mt-6 p-4 bg-primary/10 rounded-lg border border-primary/20">
              <h4 className="font-bold text-primary mb-2">{t('about.international.title')}</h4>
              <p>
                {t('about.international.text')}
              </p>
            </div>
          </div>
          <div className="bg-gray-200 h-80 rounded-lg flex items-center justify-center">
            <div className="flex flex-col items-center">
              <span className="text-gray-500">Imagem da equipe ou atividades</span>
              <span className="text-xs text-gray-400 mt-2">{t('header.tagline')}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ProjectsSection = () => {
  const { t } = useTranslation();
  
  return (
    <section className="section bg-white">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">{t('projects.title')}</h2>
          <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
          <p className="max-w-3xl mx-auto text-lg">
            {t('projects.description')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="bg-light p-6 rounded-lg shadow-md">
            <div className="bg-primary text-white p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-primary text-center mb-4">{t('projects.sports.title')}</h3>
            <p className="text-center mb-4">
              {t('projects.sports.text1')}
            </p>
            <p className="text-center">
              {t('projects.sports.text2')}
            </p>
          </div>
          
          <div className="bg-light p-6 rounded-lg shadow-md">
            <div className="bg-primary text-white p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-primary text-center mb-4">{t('projects.jiujitsu.title')}</h3>
            <p className="text-center mb-4">
              {t('projects.jiujitsu.text1')}
            </p>
            <p className="text-center">
              {t('projects.jiujitsu.text2')}
            </p>
          </div>
          
          <div className="bg-light p-6 rounded-lg shadow-md">
            <div className="bg-primary text-white p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-primary text-center mb-4">{t('projects.education.title')}</h3>
            <p className="text-center mb-4">
              {t('projects.education.text1')}
            </p>
            <p className="text-center">
              {t('projects.education.text2')}
            </p>
          </div>
          
          <div className="bg-light p-6 rounded-lg shadow-md">
            <div className="bg-primary text-white p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-primary text-center mb-4">{t('projects.protection.title')}</h3>
            <p className="text-center mb-4">
              {t('projects.protection.text1')}
            </p>
            <p className="text-center">
              {t('projects.protection.text2')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

const ImpactSection = () => {
  const { t } = useTranslation();
  
  return (
    <section className="section bg-primary text-white">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">{t('impact.title')}</h2>
          <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
          <p className="max-w-3xl mx-auto text-lg">
            {t('impact.description')}
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-4xl font-bold text-secondary mb-2">120+</div>
            <p className="text-lg">{t('impact.children')}</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-secondary mb-2">85%</div>
            <p className="text-lg">{t('impact.dropout')}</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-secondary mb-2">40+</div>
            <p className="text-lg">{t('impact.youth')}</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-secondary mb-2">10</div>
            <p className="text-lg">{t('impact.years')}</p>
          </div>
        </div>
      </div>
    </section>
  );
};

const TestimonialSection = () => {
  const { t } = useTranslation();
  
  return (
    <section className="section bg-light">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">{t('testimonials.title')}</h2>
          <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
          <p className="max-w-3xl mx-auto text-lg">
            {t('testimonials.description')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <div className="bg-primary text-white p-4 rounded-full mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div>
                <h3 className="text-xl font-bold text-primary">{t('testimonials.testimonial1.author')}</h3>
                <p className="text-gray-600">{t('testimonials.testimonial1.role')}</p>
              </div>
            </div>
            <p className="italic">
              "{t('testimonials.testimonial1.text')}"
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <div className="bg-primary text-white p-4 rounded-full mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div>
                <h3 className="text-xl font-bold text-primary">{t('testimonials.testimonial2.author')}</h3>
                <p className="text-gray-600">{t('testimonials.testimonial2.role')}</p>
              </div>
            </div>
            <p className="italic">
              "{t('testimonials.testimonial2.text')}"
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

const CallToAction = () => {
  const { t } = useTranslation();
  
  return (
    <section className="section bg-secondary text-white">
      <div className="container">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-6">{t('donate.cta.title')}</h2>
          <p className="max-w-3xl mx-auto text-lg mb-8">
            {t('donate.cta.text')}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="/doe" className="btn-accent text-center">{t('donate.cta.button1')}</a>
            <a href="/contato" className="bg-white text-secondary font-semibold py-2 px-6 rounded-md hover:bg-gray-100 transition-all text-center">{t('donate.cta.button2')}</a>
          </div>
        </div>
      </div>
    </section>
  );
};

const HomePage = () => {
  return (
    <div>
      <Hero />
      <AboutSection />
      <ProjectsSection />
      <ImpactSection />
      <TestimonialSection />
      <CallToAction />
    </div>
  );
};

export default HomePage;
