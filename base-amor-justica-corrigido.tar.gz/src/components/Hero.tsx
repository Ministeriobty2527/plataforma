import React from 'react';
import ImageCarousel from './ImageCarousel';

const Hero = () => {
  return (
    <div>
      <section className="hero-section py-20 text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Base de Amor e Justiça</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Transformando vidas através do esporte, educação e evangelho nas comunidades do Tuiuti e Mangueira.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="/quem-somos" className="btn-primary">Conheça Nossa História</a>
            <a href="/contato" className="bg-transparent border-2 border-white text-white font-semibold py-2 px-6 rounded-md hover:bg-white/10 transition-all">Entre em Contato</a>
          </div>
        </div>
      </section>
      
      {/* Carrossel de Imagens */}
      <div className="container mx-auto px-4 -mt-8 mb-12 relative z-10">
        <div className="rounded-lg shadow-xl overflow-hidden">
          <ImageCarousel />
        </div>
      </div>
    </div>
  );
};

export default Hero;
