import React from 'react';
import { useTranslation } from 'react-i18next';

const LanguageSwitcher = () => {
  const { i18n } = useTranslation();
  const { t } = useTranslation();

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
  };

  return (
    <div className="flex items-center space-x-2">
      <span className="text-sm text-gray-600">{t('language.select')}:</span>
      <button 
        className={`text-sm px-2 py-1 rounded ${i18n.language === 'pt' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700'}`}
        onClick={() => changeLanguage('pt')}
      >
        {t('language.pt')}
      </button>
      <button 
        className={`text-sm px-2 py-1 rounded ${i18n.language === 'en' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700'}`}
        onClick={() => changeLanguage('en')}
      >
        {t('language.en')}
      </button>
    </div>
  );
};

export default LanguageSwitcher;
