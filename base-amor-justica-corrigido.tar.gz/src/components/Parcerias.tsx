import React from 'react';

const Parcerias = () => {
  return (
    <section className="section bg-light">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">Nossos Parceiros</h2>
          <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
          <p className="max-w-3xl mx-auto text-lg">
            Contamos com o apoio de importantes instituições que acreditam em nosso trabalho e contribuem para a transformação de vidas.
          </p>
        </div>
        
        <div className="bg-white p-8 rounded-lg shadow-md mb-8">
          <p className="mb-6 text-lg">
            A Base de Amor e Justiça e a Plataforma Resgate são mantidas pelo <strong>Ministério BTY (Beit Tefilat Yeshua)</strong> e por parceiros e amigos que conhecem nossa credibilidade e compromisso com a transformação social.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div className="bg-light p-6 rounded-lg shadow-md">
              <div className="bg-gray-200 w-full h-32 mb-4 rounded-md flex items-center justify-center">
                <span className="text-gray-500">Logo SESC</span>
              </div>
              <h3 className="text-xl font-bold text-primary mb-2 text-center">SESC</h3>
              <p className="text-center">
                Parceria em desenvolvimento que ampliará nosso alcance e impacto nas comunidades atendidas.
              </p>
            </div>
            
            <div className="bg-light p-6 rounded-lg shadow-md">
              <div className="bg-gray-200 w-full h-32 mb-4 rounded-md flex items-center justify-center">
                <span className="text-gray-500">Logo Universidade Candido Mendes</span>
              </div>
              <h3 className="text-xl font-bold text-primary mb-2 text-center">Universidade Candido Mendes</h3>
              <p className="text-center">
                Parceria na concepção de projetos educacionais que beneficiam nossas crianças e jovens.
              </p>
            </div>
            
            <div className="bg-light p-6 rounded-lg shadow-md">
              <div className="bg-gray-200 w-full h-32 mb-4 rounded-md flex items-center justify-center">
                <span className="text-gray-500">Logo Ministério BTY</span>
              </div>
              <h3 className="text-xl font-bold text-primary mb-2 text-center">Ministério BTY</h3>
              <p className="text-center">
                Responsável pela manutenção e direção espiritual de todos os projetos da Base de Amor e Justiça.
              </p>
            </div>
            
            <div className="bg-light p-6 rounded-lg shadow-md">
              <div className="bg-gray-200 w-full h-32 mb-4 rounded-md flex items-center justify-center">
                <span className="text-gray-500">Logo The Love And Justice Project</span>
              </div>
              <h3 className="text-xl font-bold text-primary mb-2 text-center">The Love And Justice Project Inc.</h3>
              <p className="text-center">
                Parceiro internacional desde 2017, sediado em Leawood, Kansas City, liderado por John Glueck, onde Ludwig Goulart também atua como Diretor Executivo.
              </p>
            </div>
          </div>
          
          <div className="bg-primary/5 p-6 rounded-lg">
            <h3 className="text-xl font-bold text-primary mb-4">Parcerias que transformam</h3>
            <p className="mb-4">
              Graças ao apoio de nossas parcerias institucionais, conseguimos ampliar nosso impacto e oferecer serviços de qualidade para as comunidades do Tuiuti e Mangueira. A parceria com o SESC está em fase de desenvolvimento e trará novas oportunidades para nossos atendidos.
            </p>
            <p className="mb-4">
              A Universidade Candido Mendes tem sido fundamental na concepção de projetos educacionais inovadores, contribuindo com conhecimento acadêmico e metodologias pedagógicas que enriquecem nossas atividades.
            </p>
            <p className="mb-4">
              O Ministério BTY (Beit Tefilat Yeshua), fundado por judeus e árabes crentes em Yeshua há 25 anos, é o principal mantenedor da Base de Amor e Justiça desde sua fundação em 2012, garantindo a sustentabilidade e continuidade de nossas ações.
            </p>
            <p>
              Desde 2017, contamos com o apoio internacional do The Love And Justice Project Inc., sediado em Leawood, Kansas City, através do líder John Glueck. Esta parceria estratégica fortalece nossa missão e amplia nosso alcance, sendo que Ludwig Goulart também atua como Diretor Executivo desta organização, criando uma ponte entre os projetos no Brasil e nos Estados Unidos.
            </p>
          </div>
        </div>
        
        <div className="text-center">
          <h3 className="text-xl font-bold text-primary mb-4">Seja um parceiro</h3>
          <p className="max-w-2xl mx-auto mb-6">
            Sua empresa ou organização também pode fazer parte dessa rede de transformação social. Entre em contato conosco para conhecer as formas de parceria e contribuir com nosso trabalho.
          </p>
          <a href="/contato" className="btn-primary">Entre em contato</a>
        </div>
      </div>
    </section>
  );
};

export default Parcerias;
