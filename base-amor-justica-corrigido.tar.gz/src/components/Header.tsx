import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';
import { useTranslation } from 'react-i18next';
import LanguageSwitcher from './LanguageSwitcher';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { t } = useTranslation();

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              {/* Placeholder para logo */}
              <div className="bg-gray-200 w-12 h-12 mr-3 rounded-md flex items-center justify-center">
                <span className="text-gray-500 text-xs">Logo</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-display font-bold text-primary">{t('header.mainTitle')}</span>
                <span className="text-xs text-gray-600">{t('header.tagline')}</span>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-dark hover:text-primary font-medium">{t('header.home')}</Link>
            <Link to="/quem-somos" className="text-dark hover:text-primary font-medium">{t('header.about')}</Link>
            <Link to="/projetos" className="text-dark hover:text-primary font-medium">{t('header.projects')}</Link>
            <Link to="/contato" className="text-dark hover:text-primary font-medium">{t('header.contact')}</Link>
            <Link to="/doe" className="btn-accent">{t('header.donate')}</Link>
            <LanguageSwitcher />
          </nav>

          {/* Mobile Navigation Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-dark hover:text-primary focus:outline-none"
            >
              {isOpen ? (
                <XMarkIcon className="h-6 w-6" />
              ) : (
                <Bars3Icon className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isOpen && (
          <div className="md:hidden mt-4 pb-4">
            <div className="flex flex-col space-y-4">
              <Link 
                to="/" 
                className="text-dark hover:text-primary font-medium"
                onClick={() => setIsOpen(false)}
              >
                {t('header.home')}
              </Link>
              <Link 
                to="/quem-somos" 
                className="text-dark hover:text-primary font-medium"
                onClick={() => setIsOpen(false)}
              >
                {t('header.about')}
              </Link>
              <Link 
                to="/projetos" 
                className="text-dark hover:text-primary font-medium"
                onClick={() => setIsOpen(false)}
              >
                {t('header.projects')}
              </Link>
              <Link 
                to="/contato" 
                className="text-dark hover:text-primary font-medium"
                onClick={() => setIsOpen(false)}
              >
                {t('header.contact')}
              </Link>
              <Link 
                to="/doe" 
                className="btn-accent inline-block text-center"
                onClick={() => setIsOpen(false)}
              >
                {t('header.donate')}
              </Link>
              <div className="pt-2">
                <LanguageSwitcher />
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
