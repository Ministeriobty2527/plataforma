import React from 'react';

const ImageCarousel = () => {
  return (
    <div className="relative w-full overflow-hidden">
      <div className="bg-gray-200 w-full h-96 flex items-center justify-center">
        <div className="text-center">
          <h3 className="text-2xl font-bold text-gray-600 mb-4">Carrossel de Imagens</h3>
          <p className="text-gray-500">Placeholder para carrossel de imagens da Base de Amor e Justiça</p>
          <p className="text-gray-500 mt-2">Insira aqui até 5 imagens destacando os projetos e atividades</p>
        </div>
      </div>
      
      {/* Indicadores de navegação */}
      <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
        <button className="w-3 h-3 rounded-full bg-primary"></button>
        <button className="w-3 h-3 rounded-full bg-gray-400"></button>
        <button className="w-3 h-3 rounded-full bg-gray-400"></button>
        <button className="w-3 h-3 rounded-full bg-gray-400"></button>
        <button className="w-3 h-3 rounded-full bg-gray-400"></button>
      </div>
      
      {/* Botões de navegação */}
      <button className="absolute top-1/2 left-4 -translate-y-1/2 bg-white/70 hover:bg-white text-primary p-2 rounded-full">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </button>
      <button className="absolute top-1/2 right-4 -translate-y-1/2 bg-white/70 hover:bg-white text-primary p-2 rounded-full">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </button>
    </div>
  );
};

export default ImageCarousel;
